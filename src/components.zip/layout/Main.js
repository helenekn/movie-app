import React from 'react';
import { MovieList } from '../components/MovieList';

class Main extends React.Component {
    state = {
        movieList: [],
    }
    
    componentDidMount() {
        fetch('http://www.omdbapi.com/?apikey=545d2dce&s=gladiator')
            .then(response => response.json())
            .then(data => this.setState({movieList: data.Search}))
    }

    render() {
        const { movieList } = this.state;
        return (
            <main className='main container'>
                {
                    movieList.length ?
                        (<MovieList movieList={this.state.movieList} />)
                        : <h4>Loading...</h4>
                }
            </main>
        )
    }
}

export { Main };